package com.myteammanager.exceptions;

public class NoDataException extends Exception {

}
