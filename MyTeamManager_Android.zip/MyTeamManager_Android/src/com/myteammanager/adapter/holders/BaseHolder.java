package com.myteammanager.adapter.holders;

import com.myteammanager.beans.BaseBean;

import android.view.View;

public abstract class BaseHolder {

	public abstract void configureViews(View convertView, BaseBean bean);
	
}
