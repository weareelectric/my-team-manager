package com.myteammanager.listener;

import com.myteammanager.events.FacebookResponseEvent;

public interface FacebookResponseListener {

	public void postFBResponse(FacebookResponseEvent event);
}
