package com.myteammanager.listener;

public interface DialogListListener {

	public void listItemClicked(int index);
}
