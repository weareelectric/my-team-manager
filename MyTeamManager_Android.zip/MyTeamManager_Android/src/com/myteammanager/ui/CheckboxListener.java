package com.myteammanager.ui;

public interface CheckboxListener {

	public void checkboxChanged();
}
