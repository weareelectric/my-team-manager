package com.myteammanager.ui;

public interface ButtonsAlertDialogListener {

	public void button1Pressed(int alertId);

	public void button2Pressed(int alertId);

	public void button3Pressed(int alertId);

}
