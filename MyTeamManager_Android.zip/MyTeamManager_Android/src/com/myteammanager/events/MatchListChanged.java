package com.myteammanager.events;

public class MatchListChanged {

}
