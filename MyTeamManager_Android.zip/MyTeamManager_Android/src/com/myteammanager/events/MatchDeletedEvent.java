package com.myteammanager.events;

public class MatchDeletedEvent {

}
